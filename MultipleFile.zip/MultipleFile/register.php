<?php
session_start();
@include 'connect.php';

$error = array();

if(isset($_POST['submit'])){
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $gmail = mysqli_real_escape_string($conn, $_POST['gmail']);
    $password = $_POST['password']; // Plain text
    $cpassword = $_POST['cpassword']; // Plain text
    
    // Server-side Validation
    if(empty($full_name)) $error[] = 'Full name is required!';
    if(empty($username)) $error[] = 'Username is required!';
    if(empty($phone_number)) $error[] = 'Phone number is required!';
    if(!filter_var($gmail, FILTER_VALIDATE_EMAIL)) $error[] = 'Invalid email format!';
    if(strlen($password) < 6) $error[] = 'Password must be at least 6 characters!';
    if($password != $cpassword) $error[] = 'Passwords do not match!';
    
    // Check existing user
    $select = "SELECT * FROM users WHERE username = '$username' OR gmail = '$gmail'";
    $result = mysqli_query($conn, $select);
    
    if(mysqli_num_rows($result) > 0){
        $error[] = 'User already exists with this username or email!';
    }
    
    if(empty($error)){
        // It's highly recommended to hash passwords before storing them in the database.
        // For example: $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        // And then store $hashed_password in the database.
        // For this exercise, we are keeping it consistent with the provided code's plain text storage.
        $insert = "INSERT INTO users(full_name, username, phone_number, gmail, password, user_type) VALUES('$full_name','$username','$phone_number','$gmail','$password','user')";
        mysqli_query($conn, $insert);
        header('location:login.php?registration=success');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register Form</title>

   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="form-container">
   <form action="" method="post" onsubmit="return validateRegisterForm()">
      <h3>Register Now</h3>
      <?php
      // Server-side error messages
      if(isset($error) && !empty($error)){
         foreach($error as $err){
            echo '<div class="error-msg"><span>'.$err.'</span><i class="fas fa-times" onclick="this.parentElement.style.display=`none`;"></i></div>';
         }
      }
      
      // Server-side success message
      if(isset($_GET['registration']) && $_GET['registration'] == 'success'){
         echo '<div class="display_message"><span>Registration successful! Please login.</span><i class="fas fa-times" onclick="this.parentElement.style.display=`none`;"></i></div>';
      }
      ?>
      
      <!-- Client-side error message display area -->
      <div id="client-error-message" class="error-msg" style="display: none;">
        <span></span>
        <i class="fas fa-times" onclick="this.parentElement.style.display='none';"></i>
      </div>

      <div class="input-field">
         <label for="full_name">Full Name</label>
         <input type="text" id="full_name" name="full_name" placeholder="Enter your full name" required>
      </div>
      
      <div class="input-field">
         <label for="username">Username</label>
         <input type="text" id="username" name="username" placeholder="Enter your username" required>
      </div>
      
      <div class="input-field">
         <label for="phone_number">Phone Number</label>
         <input type="text" id="phone_number" name="phone_number" placeholder="Enter your phone number" required>
      </div>
      
      <div class="input-field">
         <label for="gmail">Email</label>
         <input type="email" id="gmail" name="gmail" placeholder="Enter your email" required>
      </div>
      
      <div class="input-field">
         <label for="password">Password</label>
         <input type="password" id="password" name="password" placeholder="Enter your password" required>
      </div>
      
      <div class="input-field">
         <label for="cpassword">Confirm Password</label>
         <input type="password" id="cpassword" name="cpassword" placeholder="Confirm your password" required>
      </div>
      
      <input type="submit" name="submit" value="Register Now" class="form-btn">
      
      <div class="login-link">
         <p>Already have an account? <a href="login.php">Login Now</a></p>
      </div>
   </form>
</div>

<script>
function validateRegisterForm() {
    const fullName = document.getElementById('full_name').value.trim();
    const username = document.getElementById('username').value.trim();
    const phoneNumber = document.getElementById('phone_number').value.trim();
    const gmail = document.getElementById('gmail').value.trim();
    const password = document.getElementById('password').value;
    const cpassword = document.getElementById('cpassword').value;
    
    const errorMessageDiv = document.getElementById('client-error-message');
    const errorMessageSpan = errorMessageDiv.querySelector('span');
    let errors = [];

    errorMessageDiv.style.display = 'none'; // Hide previous errors
    errorMessageSpan.textContent = ''; // Clear previous error text

    if (fullName === '') {
        errors.push('Full name is required!');
    }
    if (username === '') {
        errors.push('Username is required!');
    }
    if (phoneNumber === '') {
        errors.push('Phone number is required!');
    }
    if (gmail === '') {
        errors.push('Email is required!');
    } else if (!isValidEmail(gmail)) {
        errors.push('Invalid email format!');
    }
    if (password === '') {
        errors.push('Password is required!');
    } else if (password.length < 6) {
        errors.push('Password must be at least 6 characters!');
    }
    if (cpassword === '') {
        errors.push('Confirm password is required!');
    } else if (password !== cpassword) {
        errors.push('Passwords do not match!');
    }

    if (errors.length > 0) {
        errorMessageSpan.innerHTML = errors.join('<br>'); // Join errors with line breaks
        errorMessageDiv.style.display = 'flex'; // Use flex for proper icon alignment
        return false;
    }
    return true;
}

function isValidEmail(email) {
    // Simple regex for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
</script>

</body>
</html>
