<?php
include 'connect.php';
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
}

if(isset($_GET['delete'])){
    $delete_id = $_GET['delete'];
    $delete_query = mysqli_query($conn, "DELETE FROM `products` WHERE id = $delete_id");
    
    if($delete_query){
        header('Location: view_products.php'); 
        exit(); 
    } else {
        echo "Product not deleted";
        header('Location: view_products.php'); 
        exit();
    }
}

if(isset($_GET['delete_doctor'])){
    $delete_id = $_GET['delete_doctor'];
    $delete_query = mysqli_query($conn, "DELETE FROM `doctors` WHERE id = $delete_id");
    
    if($delete_query){
        header('Location: view_doctors.php'); 
        exit(); 
    } else {
        echo "Doctor not deleted";
        header('Location: view_doctors.php'); 
        exit();
    }
}
?>
