<?php include 'connect.php';
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Doctors</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" crossorigin="anonymous" />
</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container">
        <section class="display_doctor">
            <h1 class="heading">Doctors List</h1>
            <table>
                <thead>
                    <th>Sl No</th>
                    <th>Image</th>
                    <th>Doctor Name</th>
                    <th>Specialization</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php
                    $select_doctors = mysqli_query($conn, "SELECT * FROM `doctors`");
                    $num = 1;
                    if (mysqli_num_rows($select_doctors) > 0) {
                        while ($row = mysqli_fetch_assoc($select_doctors)) {
                    ?>
                            <tr>
                                <td><?php echo $num; ?></td>
                                <td><img src="images/<?php echo $row['image'] ?>" alt="<?php echo $row['name']; ?>"></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['specialization']; ?></td>
                                <td>
                                    <a href="delete.php?delete_doctor=<?php echo $row['id']; ?>" class="delete_doctor_btn" onclick="return confirm('Are you sure?');">
                                        <i class="fas fa-trash"></i> Delete</a>
                                    <a href="update.php?edit_doctor=<?php echo $row['id']; ?>" class="update_doctor_btn">
                                        <i class="fas fa-edit"></i> Edit</a>
                                </td>
                            </tr>
                    <?php
                            $num++;
                        }
                    } else {
                        echo "<tr><td colspan='5' class='empty_text'>No Doctors Available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </div>
</body>

</html>