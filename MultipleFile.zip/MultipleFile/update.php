<?php
include 'connect.php';
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
   exit();
}

// Update Product Logic
if (isset($_POST['update_product'])) {
    $update_product_id = mysqli_real_escape_string($conn, $_POST['update_product_id']);
    $update_product_name = mysqli_real_escape_string($conn, $_POST['update_product_name']);
    $update_product_price = mysqli_real_escape_string($conn, $_POST['update_product_price']);
    $update_product_category = mysqli_real_escape_string($conn, $_POST['update_product_category']); // New: Get category

    $update_product_image = $_FILES['update_product_image']['name'];
    $update_product_image_tmp_name = $_FILES['update_product_image']['tmp_name'];
    $update_product_image_folder = 'images/' . $update_product_image;

    if (!empty($update_product_image)) {
        // Update query with new image and category
        $update_product = mysqli_query($conn, "UPDATE `products` SET
            name='$update_product_name', price='$update_product_price', category='$update_product_category',
            image='$update_product_image' WHERE id=$update_product_id");
        move_uploaded_file($update_product_image_tmp_name, $update_product_image_folder);
    } else {
        // Update query without changing image, but including category
        $update_product = mysqli_query($conn, "UPDATE `products` SET
            name='$update_product_name', price='$update_product_price', category='$update_product_category' WHERE id=$update_product_id");
    }

    if ($update_product) {
        header('location:view_products.php');
        exit();
    } else {
        echo "Product not updated";
    }
}

// Update Doctor Logic (remains unchanged)
if (isset($_POST['update_doctor'])) {
    $update_doctor_id = mysqli_real_escape_string($conn, $_POST['update_doctor_id']);
    $update_doctor_name = mysqli_real_escape_string($conn, $_POST['update_doctor_name']);
    $update_doctor_specialization = mysqli_real_escape_string($conn, $_POST['update_doctor_specialization']);
    $update_doctor_experience = mysqli_real_escape_string($conn, $_POST['update_doctor_experience']);

    $update_doctor_image = $_FILES['update_doctor_image']['name'];
    $update_doctor_image_tmp_name = $_FILES['update_doctor_image']['tmp_name'];
    $update_doctor_image_folder = 'images/' . $update_doctor_image;

    if (!empty($update_doctor_image)) {
        // Update query with new image
        $update_doctor = mysqli_query($conn, "UPDATE `doctors` SET
            name='$update_doctor_name', specialization='$update_doctor_specialization', experience='$update_doctor_experience',
            image='$update_doctor_image' WHERE id=$update_doctor_id");
        move_uploaded_file($update_doctor_image_tmp_name, $update_doctor_image_folder);
    } else {
        // Update query without changing image
        $update_doctor = mysqli_query($conn, "UPDATE `doctors` SET
            name='$update_doctor_name', specialization='$update_doctor_specialization', experience='$update_doctor_experience' WHERE id=$update_doctor_id");
    }

    if ($update_doctor) {
        header('location:view_doctors.php');
        exit();
    } else {
        echo "Doctor not updated";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Page</title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <section>
        <?php
            // Fetch product data if 'edit' is set in GET request
            if (isset($_GET['edit'])) {
                $edit_id = $_GET['edit'];
                $edit_query = mysqli_query($conn, "SELECT * FROM `products` WHERE id=$edit_id");

                if (mysqli_num_rows($edit_query) > 0) {
                    $fetch_data = mysqli_fetch_assoc($edit_query);
        ?>
            <form action="" method="post" enctype="multipart/form-data" class="update_form product_container_box">
                <h3>Update Product</h3>
                <img src="images/<?php echo $fetch_data['image']; ?>" alt="">
                <input type="hidden" value="<?php echo $fetch_data['id']; ?>" name="update_product_id">
                <input type="text" class="input_fields fields" required value="<?php echo $fetch_data['name']; ?>" name="update_product_name">
                <input type="number" class="input_fields fields" required value="<?php echo $fetch_data['price']; ?>" name="update_product_price">
                
                <!-- New: Category Dropdown for Update -->
                <select name="update_product_category" class="input_fields fields" required>
                    <option value="Tablets" <?php echo ($fetch_data['category'] == 'Tablets') ? 'selected' : ''; ?>>Tablets</option>
                    <option value="Syrups" <?php echo ($fetch_data['category'] == 'Syrups') ? 'selected' : ''; ?>>Syrups</option>
                    <option value="Injections" <?php echo ($fetch_data['category'] == 'Injections') ? 'selected' : ''; ?>>Injections</option>
                    <option value="Pain Relievers" <?php echo ($fetch_data['category'] == 'Pain Relievers') ? 'selected' : ''; ?>>Pain Relievers</option>
                    <option value="Antibiotics" <?php echo ($fetch_data['category'] == 'Antibiotics') ? 'selected' : ''; ?>>Antibiotics</option>
                    <option value="Vitamins & Supplements" <?php echo ($fetch_data['category'] == 'Vitamins & Supplements') ? 'selected' : ''; ?>>Vitamins & Supplements</option>
                    <option value="Uncategorized" <?php echo ($fetch_data['category'] == 'Uncategorized') ? 'selected' : ''; ?>>Uncategorized</option>
                </select>

                <input type="file" class="input_fields fields" accept="image/png, image/jpg, image/jpeg" name="update_product_image">

                <div class="btns">
                    <input type="submit" class="edit_btn" value="Update Product" name="update_product">
                    <a href="view_products.php" class="cancel_btn">Cancel</a>
                </div>
            </form>
        <?php
                } else {
                    echo "Product not found.";
                }
            } elseif (isset($_GET['edit_doctor'])) {
                // Fetch doctor data if 'edit_doctor' is set in GET request
                $edit_id = $_GET['edit_doctor'];
                $edit_query = mysqli_query($conn, "SELECT * FROM `doctors` WHERE id=$edit_id");

                if (mysqli_num_rows($edit_query) > 0) {
                    $fetch_data = mysqli_fetch_assoc($edit_query);
        ?>
            <form action="" method="post" enctype="multipart/form-data" class="update_form product_container_box">
                <h3>Update Doctor</h3>
                <img src="images/<?php echo $fetch_data['image']; ?>" alt="">
                <input type="hidden" value="<?php echo $fetch_data['id']; ?>" name="update_doctor_id">
                <input type="text" class="input_fields fields" required value="<?php echo $fetch_data['name']; ?>" name="update_doctor_name">
                <input type="text" class="input_fields fields" required value="<?php echo $fetch_data['specialization']; ?>" name="update_doctor_specialization">
                <input type="text" class="input_fields fields" required value="<?php echo $fetch_data['experience']; ?>" name="update_doctor_experience">
                <input type="file" class="input_fields fields" accept="image/png, image/jpg, image/jpeg" name="update_doctor_image">

                <div class="btns">
                    <input type="submit" class="edit_btn" value="Update Doctor" name="update_doctor">
                    <a href="view_doctors.php" class="cancel_btn">Cancel</a>
                </div>
            </form>
        <?php
                } else {
                    echo "Doctor not found.";
                }
            } else {
                echo "<p class='error-msg'>No item selected for update.</p>";
            }
        ?>
    </section>
</div>

</body>
</html>
