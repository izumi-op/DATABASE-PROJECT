<?php

$conn = mysqli_connect('localhost','root','','medical_shop') or die("Connection Fail");

?>
