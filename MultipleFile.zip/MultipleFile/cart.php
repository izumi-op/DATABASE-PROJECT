<?php
@include 'connect.php';
session_start();

if(!isset($_SESSION['user_id'])){
   header('location:login.php'); // Redirect to login if not logged in
}

$user_id = $_SESSION['user_id'];

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM `cart` WHERE id = '$remove_id' AND user_id = '$user_id'");
   header('location:cart.php');
};

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `cart` WHERE user_id = '$user_id'");
   header('location:cart.php');
};

if(isset($_POST['update_cart'])){
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    mysqli_query($conn, "UPDATE `cart` SET quantity = '$quantity' WHERE id = '$cart_id' AND user_id = '$user_id'");
    header('location:cart.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Shopping Cart</title>
   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
   <section class="shopping-cart">
      <h1 class="heading">Shopping Cart</h1>

      <table>
         <thead>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Action</th>
         </thead>
         <tbody>
         <?php
            $grand_total = 0;
            $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
            if(mysqli_num_rows($select_cart) > 0){
               while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>
            <tr>
               <td><img src="images/<?php echo $fetch_cart['image']; ?>" height="100" alt=""></td>
               <td><?php echo $fetch_cart['name']; ?></td>
               <td><?php echo $fetch_cart['price']; ?> Taka</td>
               <td>
                  <form action="" method="post">
                     <input type="hidden" name="cart_id" value="<?php echo $fetch_cart['id']; ?>">
                     <input type="number" min="1" value="<?php echo $fetch_cart['quantity']; ?>" name="quantity" class="qty">
                     <input type="submit" value="update" name="update_cart" class="option-btn">
                  </form>   
               </td>
               <td><?php echo $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?> Taka</td>
               <td><a href="cart.php?remove=<?php echo $fetch_cart['id']; ?>" class="delete-btn" onclick="return confirm('remove item from cart?');">remove</a></td>
            </tr>
         <?php
           $grand_total += $sub_total;  
            };
         }else{
            echo '<tr><td style="padding:20px; text-transform:capitalize;" colspan="6">no item added</td></tr>';
         };
         ?>
         <tr class="table-bottom">
            <td colspan="4">grand total :</td>
            <td><?php echo $grand_total; ?> Taka</td>
            <td><a href="cart.php?delete_all" onclick="return confirm('delete all from cart?');" class="delete-btn <?php echo ($grand_total > 0)?'':'disabled'; ?>">delete all</a></td>
         </tr>
         </tbody>
      </table>
      <div class="checkout-btn">
         <a href="shop_products.php" class="btn">continue shopping</a>
         <a href="#" class="btn <?php echo ($grand_total > 0)?'':'disabled'; ?>">proceed to checkout</a>
      </div>
   </section>
</div>
</body>
</html>