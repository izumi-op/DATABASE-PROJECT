<?php
session_start();
@include 'connect.php';

$error = array();

if(isset($_POST['submit'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Plain text

    $select = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");

    if(mysqli_num_rows($select) > 0){
        $row = mysqli_fetch_assoc($select);

        // Direct password comparison
        if($password === $row['password']){
            if($row['user_type'] == 'admin'){
                $_SESSION['admin_name'] = $row['username'];
                // Admin user_id is not strictly needed for cart, but good for consistency
                $_SESSION['user_id'] = $row['id'];
                header('location:admin_page.php');
            } else {
                $_SESSION['user_name'] = $row['username'];
                $_SESSION['user_id'] = $row['id']; // Set user_id for regular users
                header('location:user_page.php');
            }
            exit();
        } else {
            $error[] = 'Incorrect password!';
        }
    } else {
        $error[] = 'Username not found!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login Form</title>

   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<div class="form-container">
   <form action="" method="post" onsubmit="return validateLoginForm()">
      <h3>Login Now</h3>
      <?php
      if(isset($error) && !empty($error)){
         foreach($error as $err){
            echo '<div class="error-msg"><span>'.$err.'</span><i class="fas fa-times" onclick="this.parentElement.style.display=`none`;"></i></div>';
         }
      }
      ?>
      <div id="client-error-message" class="error-msg" style="display: none;">
        <span></span>
        <i class="fas fa-times" onclick="this.parentElement.style.display='none';"></i>
      </div>

      <div class="input-field">
         <label for="username">Username</label>
         <input type="text" id="username" name="username" placeholder="Enter your username" required>
      </div>
      <div class="input-field">
         <label for="password">Password</label>
         <input type="password" id="password" name="password" placeholder="Enter your password" required>
      </div>
      <input type="submit" name="submit" value="Login Now" class="form-btn">
      <div class="register-link">
         <p>Don't have an account? <a href="register.php">Register Now</a></p>
      </div>
   </form>
</div>

<script>
function validateLoginForm() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorMessageDiv = document.getElementById('client-error-message');
    const errorMessageSpan = errorMessageDiv.querySelector('span');

    errorMessageDiv.style.display = 'none'; // Hide previous errors

    if (username === '' || password === '') {
        errorMessageSpan.textContent = 'Please fill in all fields.';
        errorMessageDiv.style.display = 'flex'; // Use flex for proper icon alignment
        return false;
    }
    return true;
}
</script>

</body>
</html>
