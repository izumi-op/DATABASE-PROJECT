<?php
include 'connect.php'; // Include the database connection
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
   exit(); // Always exit after a header redirect
}

if (isset($_POST['add_product'])) {
    // Retrieve product details from the form
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $product_price = mysqli_real_escape_string($conn, $_POST['product_price']);
    $product_category = mysqli_real_escape_string($conn, $_POST['product_category']); // New: Get category
    $product_image = $_FILES['product_image']['name'];
    $product_image_temp_name = $_FILES['product_image']['tmp_name'];
    
    // Define the folder where the uploaded image will be stored
    $product_image_folder = 'images/' . $product_image;
    
    // Insert product details into the database, including category
    $insert_query = mysqli_query($conn, "INSERT INTO `products` (name, price, image, category) VALUES ('$product_name', '$product_price', '$product_image', '$product_category')") or die("Insert query Failed");
    
    if ($insert_query) {
        // Move the uploaded image to the folder
        move_uploaded_file($product_image_temp_name, $product_image_folder);
        $display_message = "Product Added Successfully";
    } else {
        $display_message ="There is some error inserting product";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <?php
    if(isset($display_message)){
        echo "<div class='display_message'>
        <span>$display_message</span>
        <i class='fas fa-times' onclick='this.parentElement.style.display=`none`';></i>
        </div>";
    }
    ?>
    
    <section>
        <h3 class="heading">Add Products</h3>
        <form action="" method="post" enctype="multipart/form-data" class="product_container_box">
            <input type="text" name="product_name" placeholder="Enter Product Name" class="input_fields" required>
            <input type="number" name="product_price" placeholder="Enter Product Price" class="input_fields" required>
            
            <!-- New: Category Dropdown -->
            <select name="product_category" class="input_fields" required>
                <option value="" disabled selected>Select Category</option>
                <option value="Tablets">Tablets</option>
                <option value="Syrups">Syrups</option>
                <option value="Injections">Injections</option>
                <option value="Pain Relievers">Pain Relievers</option>
                <option value="Antibiotics">Antibiotics</option>
                <option value="Vitamins & Supplements">Vitamins & Supplements</option>
                <option value="Uncategorized">Uncategorized</option>
            </select>

            <input type="file" name="product_image" accept="image/png, image/jpg, image/jpeg" class="input_fields" required>
            <input type="submit" name="add_product" value="Add Product" class="submit_btn">
        </form>
    </section>
</div>

</body>
</html>
