<?php
@include 'connect.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
} // Start the session

$row_count = 0; // Initialize row_count

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    // Count items in cart for the logged-in user
    $select_product = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
    $row_count = mysqli_num_rows($select_product);
}

// Get the current page filename to highlight the active link
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Store</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header class="header">
        <a href="index.php" class="company_Name">Medical Store</a>
        <nav class="navbar">
            <!-- Home Link - Always visible -->
            <a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">Home</a>
            
            <?php if (!isset($_SESSION['admin_name'])): // Show these links only if NOT an admin ?>
                <!-- Shop Link -->
                <a href="shop_products.php" class="<?php echo ($current_page == 'shop_products.php') ? 'active' : ''; ?>">Shop</a>
                <!-- New: View Doctors link for non-admins -->
                <a href="view_doctors_user.php" class="<?php echo ($current_page == 'view_doctors_user.php') ? 'active' : ''; ?>">View Doctors</a>
            <?php endif; ?>

            <!-- Dynamic Profile/Login/Register Links -->
            <?php if (isset($_SESSION['admin_name'])): ?>
                <a href="admin_page.php" class="<?php echo ($current_page == 'admin_page.php') ? 'active' : ''; ?>">Admin Profile</a>
            <?php elseif (isset($_SESSION['user_name'])): ?>
                <a href="user_page.php" class="<?php echo ($current_page == 'user_page.php') ? 'active' : ''; ?>">User Profile</a>
            <?php else: ?>
                <a href="login.php" class="<?php echo ($current_page == 'login.php') ? 'active' : ''; ?>">Login</a>
                <a href="register.php" class="<?php echo ($current_page == 'register.php') ? 'active' : ''; ?>">Register</a>
            <?php endif; ?>

            <?php if (!isset($_SESSION['admin_name'])): // Show these links only if NOT an admin ?>
                <!-- Contact Link (placeholder, as no contact.php was provided) -->
                <a href="contact.php" class="<?php echo ($current_page == 'contact.php') ? 'active' : ''; ?>">Contact</a>
            <?php endif; ?>
            
            <!-- Logout Link (visible if any user is logged in) -->
            <?php if (isset($_SESSION['user_name']) || isset($_SESSION['admin_name'])): ?>
                <a href="logout.php">Logout</a>
                <?php if (!isset($_SESSION['admin_name'])): // Show cart only if NOT an admin ?>
                    <!-- Cart Link (moved to last, visible only if user is logged in AND not admin) -->
                    <a href="cart.php" class="cart <?php echo ($current_page == 'cart.php') ? 'active' : ''; ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-badge"><?php echo $row_count; ?></span>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>
    </header>
</body>
</html>
