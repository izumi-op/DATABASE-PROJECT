<?php
@include 'connect.php';
session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>User Page</title>

   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
   
<?php include 'header.php'; ?>
   
   <div class="container">
      <section class="user_content">
         <div class="content">
            <h3>Hi, <span><?php echo $_SESSION['user_name']; ?></span></h3>
            <h1>Welcome <span>User</span></h1>
            <p>This is the User dashboard. You can Shop Product and See Cart from here.</p>
            <a href="shop_products.php" class="btn">Shop Products</a>
            <a href="cart.php" class="btn">Cart</a>
         </div>
      </section>
   </div>

</body>
</html>