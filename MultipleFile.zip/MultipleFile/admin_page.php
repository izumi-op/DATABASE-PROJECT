<?php
@include 'connect.php';
session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login.php');
   exit(); // Always exit after a header redirect
}

// Fetch quick stats from the database
// Total Registered Users (excluding admin if user_type 'user' is specific)
$total_users = 0;
$select_users = mysqli_query($conn, "SELECT COUNT(*) AS total_users FROM `users` WHERE user_type = 'user'");
if ($select_users && mysqli_num_rows($select_users) > 0) {
    $users_data = mysqli_fetch_assoc($select_users);
    $total_users = $users_data['total_users'];
}

// Total Products
$total_products = 0;
$select_products = mysqli_query($conn, "SELECT COUNT(*) AS total_products FROM `products`");
if ($select_products && mysqli_num_rows($select_products) > 0) {
    $products_data = mysqli_fetch_assoc($select_products);
    $total_products = $products_data['total_products'];
}

// Total Doctors
$total_doctors = 0;
$select_doctors = mysqli_query($conn, "SELECT COUNT(*) AS total_doctors FROM `doctors`");
if ($select_doctors && mysqli_num_rows($select_doctors) > 0) {
    $doctors_data = mysqli_fetch_assoc($select_doctors);
    $total_doctors = $doctors_data['total_doctors'];
}

// Total Items in all users' carts (sum of quantities)
$total_cart_items = 0;
$select_cart_items = mysqli_query($conn, "SELECT SUM(quantity) AS total_items FROM `cart`");
if ($select_cart_items && mysqli_num_rows($select_cart_items) > 0) {
    $cart_data = mysqli_fetch_assoc($select_cart_items);
    // Use ternary operator to handle NULL if SUM returns NULL (empty cart)
    $total_cart_items = $cart_data['total_items'] ? $cart_data['total_items'] : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Dashboard</title>

   <link rel="stylesheet" href="style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
   
<?php include 'header.php'; ?>
   
   <div class="container">
      <section class="admin_content">
         <div class="content">
            <h3>Hi, <span><?php echo $_SESSION['admin_name'] ?></span></h3>
            <h1>Welcome to Admin Dashboard</h1>
            <p>Overview and quick actions for your medical shop.</p>
         </div>

         <!-- Quick Stats Section -->
         <div class="dashboard-section">
             <h2 class="section-heading">Quick Stats</h2>
             <div class="stats-grid">
                 <div class="stat-box">
                     <i class="fas fa-users"></i>
                     <h3><?php echo $total_users; ?></h3>
                     <p>Registered Users</p>
                 </div>
                 <div class="stat-box">
                     <i class="fas fa-pills"></i>
                     <h3><?php echo $total_products; ?></h3>
                     <p>Total Products</p>
                 </div>
                 <div class="stat-box">
                     <i class="fas fa-user-md"></i>
                     <h3><?php echo $total_doctors; ?></h3>
                     <p>Total Doctors</p>
                 </div>
                 <div class="stat-box">
                     <i class="fas fa-shopping-cart"></i>
                     <h3><?php echo $total_cart_items; ?></h3>
                     <p>Items in Carts</p>
                 </div>
             </div>
         </div>

         <!-- Management Actions Section (Tiles) -->
         <div class="dashboard-section">
             <h2 class="section-heading">Management Actions</h2>
             <div class="tiles-grid">
                 <a href="add_products.php" class="tile-box">
                     <i class="fas fa-plus-circle"></i>
                     <h3>Add New Product</h3>
                     <p>Add new medicines or health products to the store.</p>
                 </a>
                 <a href="view_products.php" class="tile-box">
                     <i class="fas fa-list-alt"></i>
                     <h3>View Products</h3>
                     <p>Manage existing products: edit details or delete.</p>
                 </a>
                 <a href="add_doctors.php" class="tile-box">
                     <i class="fas fa-user-plus"></i>
                     <h3>Add New Doctor</h3>
                     <p>Register new doctors with their specializations.</p>
                 </a>
                 <a href="view_doctors.php" class="tile-box">
                     <i class="fas fa-users-medical"></i>
                     <h3>View Doctors</h3>
                     <p>Manage doctor profiles: edit details or remove.</p>
                 </a>
             </div>
         </div>
      </section>
   </div>

</body>
</html>
