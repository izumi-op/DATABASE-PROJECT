<?php
include 'connect.php';
session_start(); // Start the session

if(!isset($_SESSION['user_id'])){
    header('location:login.php'); // Redirect to login if not logged in
    exit();
}

if(isset($_POST['add_to_cart'])){
    $user_id = $_SESSION['user_id'];
    $products_name = $_POST['product_name'];
    $products_price = $_POST['product_price'];
    $products_image = $_POST['product_image'];
    $products_quantity = 1;

    $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name='$products_name' AND user_id = '$user_id'");
    
    if (mysqli_num_rows($select_cart) > 0) {
        $display_message[] = "Product already added to cart";
    } else {
        $insert_products = mysqli_query($conn, "INSERT INTO `cart` (user_id, name, price, image, quantity) VALUES ('$user_id', '$products_name','$products_price','$products_image','$products_quantity')");
        $display_message[] = "Product added to cart";
    }
}

// Build the SQL query based on search and filter
$sql = "SELECT * FROM `products`";
$conditions = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = mysqli_real_escape_string($conn, $_GET['search']);
    $conditions[] = "name LIKE '%$search_term%'";
}

if (isset($_GET['category']) && !empty($_GET['category']) && $_GET['category'] != 'all') {
    $category_filter = mysqli_real_escape_string($conn, $_GET['category']);
    $conditions[] = "category = '$category_filter'";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$select_products = mysqli_query($conn, $sql);

// Fetch unique categories for the filter dropdown
$categories_query = mysqli_query($conn, "SELECT DISTINCT category FROM `products`");
$categories = [];
if ($categories_query) {
    while ($cat_row = mysqli_fetch_assoc($categories_query)) {
        $categories[] = $cat_row['category'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Products</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" xintegrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <?php include 'header.php'; ?>

    <div class="container">
        <?php
            if(isset($display_message)){
                echo '<div class="display_message">
                    <span>'.$display_message[0].'</span>
                    <i class="fas fa-times" onclick="this.parentElement.style.display=`none`";></i>
                </div>';
            }
        ?>
        <section class="products">
            <h1 class="heading">Let's Shop</h1>

            <!-- Search and Filter Section -->
            <div class="filter-controls">
                <form action="" method="GET" class="filter-form">
                    <div class="search-box">
                        <input type="text" name="search" placeholder="Search products..." class="input_fields" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit" class="btn search-btn"><i class="fas fa-search"></i></button>
                    </div>
                    
                    <div class="category-filter">
                        <select name="category" class="input_fields">
                            <option value="all">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo (isset($_GET['category']) && $_GET['category'] == $cat) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn filter-btn"><i class="fas fa-filter"></i> Filter</button>
                    </div>
                </form>
            </div>


            <div class="product_container">
                <?php
                if(mysqli_num_rows($select_products) > 0){
                    while($fetch_product = mysqli_fetch_assoc($select_products)){
                ?>
                <form action="" method="post">
                    <div class="edit_form">
                        <img src="images/<?php echo $fetch_product['image']; ?>" alt="Product Image">
                        <h3><?php echo $fetch_product['name']; ?></h3>
                        <p class="product-category"><?php echo htmlspecialchars($fetch_product['category']); ?></p> <!-- Display Category -->
                        <div class="price">Price: <?php echo number_format($fetch_product['price'], 2); ?> Taka</div>
                        <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
                        <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
                        <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
                        <input type="submit" class="submit_btn cart_btn" value="Add to Cart" name="add_to_cart">
                    </div>
                </form>
                <?php
                    }
                } else {
                    echo "<div class='empty_text'>No Products Available matching your criteria.</div>"; 
                }
                ?>
            </div>
        </section>
    </div>
</body>
</html>
